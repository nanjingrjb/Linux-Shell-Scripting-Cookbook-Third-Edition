cat /etc/passwd |grep -v nologin |grep -v halt|grep -v shutdown |awk -F ":" '{ print $1"|"$3"|"$4}'|more
