cd ./testfind
for i in `ls`
do rm -r $i
done
