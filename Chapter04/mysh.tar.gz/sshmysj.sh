#!/bin/bash

sshpass -p 123456 ssh -A -g u0_a742@192.168.3.31 -p 8022
