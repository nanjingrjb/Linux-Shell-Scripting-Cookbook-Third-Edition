echo "完整格式显示时间"
date +%Y%m%d%H%M%S

echo "简写格式显示时间"
date +%y%m%d%H%M%S

