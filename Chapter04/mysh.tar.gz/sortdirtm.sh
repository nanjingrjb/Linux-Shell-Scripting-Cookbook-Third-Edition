#########################################################################
# File Name: sortdirtm.sh
# Author: ma6174
# mail: ma6174@163.com
# Created Time: Sat Apr 15 17:52:55 2023
#########################################################################
#!/bin/bash
sort -k 6.1nbr  -k 6.6nbr -k 6.9nbr -k 7.1nbr -k 7.4nbr lsdir.txt 
