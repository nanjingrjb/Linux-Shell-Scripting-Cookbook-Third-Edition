echo "this is ling's book,it cost \$5.00"
